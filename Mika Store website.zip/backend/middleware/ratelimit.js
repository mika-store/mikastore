const rateLimit = require('express-rate-limit');

const createRateLimiter = (windowMs = 15 * 60 * 1000, max = 100) => {
  return rateLimit({
    windowMs,
    max,
    message: {
      status: 'error',
      message: 'Terlalu banyak permintaan. Coba lagi nanti.'
    },
    standardHeaders: true,
    legacyHeaders: false
  });
};

const authLimiter = createRateLimiter(15 * 60 * 1000, 10);
const apiLimiter = createRateLimiter(15 * 60 * 1000, 100);

module.exports = { createRateLimiter, authLimiter, apiLimiter };