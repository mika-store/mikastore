const jwt = require('jsonwebtoken');
const User = require('../models/User');

const auth = async (req, res, next) => {
  try {
    const token = req.cookies.token || req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({
        status: 'error',
        message: 'Akses ditolak. Silakan login.'
      });
    }
    
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id).select('-password');
    
    if (!user) {
      return res.status(401).json({
        status: 'error',
        message: 'User tidak ditemukan.'
      });
    }
    
    if (!user.isActive) {
      return res.status(403).json({
        status: 'error',
        message: 'Akun Anda dinonaktifkan.'
      });
    }
    
    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({
        status: 'error',
        message: 'Sesi habis. Silakan login ulang.'
      });
    }
    return res.status(401).json({
      status: 'error',
      message: 'Token tidak valid.'
    });
  }
};

const admin = async (req, res, next) => {
  if (req.user.role !== 'admin' && req.user.role !== 'superadmin') {
    return res.status(403).json({
      status: 'error',
      message: 'Akses ditolak. Hanya admin.'
    });
  }
  next();
};

const superAdmin = async (req, res, next) => {
  if (req.user.role !== 'superadmin') {
    return res.status(403).json({
      status: 'error',
      message: 'Akses ditolak. Hanya Super Admin.'
    });
  }
  next();
};

module.exports = { auth, admin, superAdmin };