const admin = (req, res, next) => {
  if (req.user.role !== 'admin' && req.user.role !== 'superadmin') {
    return res.status(403).json({
      status: 'error',
      message: 'Akses ditolak. Hanya admin.'
    });
  }
  next();
};

const superAdmin = (req, res, next) => {
  if (req.user.role !== 'superadmin') {
    return res.status(403).json({
      status: 'error',
      message: 'Akses ditolak. Hanya Super Admin.'
    });
  }
  next();
};

module.exports = { admin, superAdmin };