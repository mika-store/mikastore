{
  "name": "mika-store-backend",
  "version": "2.0.0",
  "description": "Mika Store Backend API",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js",
    "seed": "node utils/seed.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "mongoose": "^7.5.0",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "dotenv": "^16.3.1",
    "cors": "^2.8.5",
    "helmet": "^7.0.0",
    "express-rate-limit": "^6.10.0",
    "express-validator": "^7.0.1",
    "express-mongo-sanitize": "^2.2.0",
    "xss": "^1.0.14",
    "csurf": "^1.11.0",
    "cookie-parser": "^1.4.6",
    "express-session": "^1.17.3",
    "connect-mongo": "^5.0.0",
    "uuid": "^9.0.1",
    "axios": "^1.6.0",
    "moment": "^2.29.4"
  },
  "devDependencies": {
    "nodemon": "^3.0.1"
  }
}