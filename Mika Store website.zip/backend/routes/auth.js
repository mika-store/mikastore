const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const { authLimiter } = require('../middleware/rateLimit');
const { auth } = require('../middleware/auth');

// ==========================================
//   REGISTER
// ==========================================

router.post('/register',
  authLimiter,
  [
    body('username')
      .isLength({ min: 3, max: 30 })
      .matches(/^[a-zA-Z0-9_]+$/)
      .withMessage('Username hanya boleh huruf, angka, dan underscore'),
    body('email')
      .isEmail()
      .normalizeEmail()
      .withMessage('Email tidak valid'),
    body('password')
      .isLength({ min: 8 })
      .withMessage('Password minimal 8 karakter')
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .withMessage('Password harus mengandung huruf besar, kecil, dan angka'),
    body('confirmPassword')
      .custom((value, { req }) => value === req.body.password)
      .withMessage('Konfirmasi password tidak sama')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          status: 'error',
          errors: errors.array().map(e => ({ field: e.param, message: e.msg }))
        });
      }

      const { username, email, password } = req.body;

      const existingUser = await User.findOne({ $or: [{ email }, { username }] });
      if (existingUser) {
        return res.status(409).json({
          status: 'error',
          message: existingUser.email === email ? 'Email sudah terdaftar' : 'Username sudah digunakan'
        });
      }

      const user = new User({ username, email, password });
      await user.save();

      const token = jwt.sign(
        { id: user._id, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRE }
      );

      res.cookie('token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000
      });

      res.status(201).json({
        status: 'success',
        data: { user: user.toJSON(), token }
      });
    } catch (error) {
      console.error('Register error:', error);
      res.status(500).json({ status: 'error', message: 'Gagal mendaftar' });
    }
  }
);

// ==========================================
//   LOGIN
// ==========================================

router.post('/login',
  authLimiter,
  [
    body('email').isEmail().withMessage('Email tidak valid'),
    body('password').notEmpty().withMessage('Password wajib diisi')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          status: 'error',
          errors: errors.array().map(e => ({ field: e.param, message: e.msg }))
        });
      }

      const { email, password } = req.body;

      const user = await User.findOne({ email });
      if (!user) {
        return res.status(401).json({
          status: 'error',
          message: 'Email atau password salah'
        });
      }

      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        return res.status(401).json({
          status: 'error',
          message: 'Email atau password salah'
        });
      }

      if (!user.isActive) {
        return res.status(403).json({
          status: 'error',
          message: 'Akun Anda dinonaktifkan'
        });
      }

      user.lastLogin = new Date();
      await user.save();

      const token = jwt.sign(
        { id: user._id, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRE }
      );

      res.cookie('token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000
      });

      res.json({
        status: 'success',
        data: { user: user.toJSON(), token }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ status: 'error', message: 'Gagal login' });
    }
  }
);

// ==========================================
//   LOGOUT
// ==========================================

router.post('/logout', auth, (req, res) => {
  res.clearCookie('token');
  res.json({ status: 'success', message: 'Berhasil logout' });
});

// ==========================================
//   GET CURRENT USER
// ==========================================

router.get('/me', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-password');
    res.json({ status: 'success', data: user });
  } catch (error) {
    res.status(500).json({ status: 'error', message: 'Gagal mengambil data user' });
  }
});

// ==========================================
//   CHANGE PASSWORD
// ==========================================

router.post('/change-password',
  auth,
  [
    body('oldPassword').notEmpty().withMessage('Password lama wajib diisi'),
    body('newPassword')
      .isLength({ min: 8 })
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .withMessage('Password baru minimal 8 karakter dengan huruf besar, kecil, dan angka')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          status: 'error',
          errors: errors.array().map(e => ({ field: e.param, message: e.msg }))
        });
      }

      const { oldPassword, newPassword } = req.body;
      const user = await User.findById(req.user._id);

      const isMatch = await user.comparePassword(oldPassword);
      if (!isMatch) {
        return res.status(401).json({
          status: 'error',
          message: 'Password lama salah'
        });
      }

      user.password = newPassword;
      await user.save();

      res.json({ status: 'success', message: 'Password berhasil diubah' });
    } catch (error) {
      res.status(500).json({ status: 'error', message: 'Gagal mengubah password' });
    }
  }
);

module.exports = router;