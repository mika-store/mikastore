const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const ronzzpay = require('../utils/ronzzpay');
const { body, validationResult } = require('express-validator');

// ==========================================
//   CEK SALDO
// ==========================================

router.get('/balance', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('saldo');
    res.json({
      status: 'success',
      data: { saldo: user.saldo }
    });
  } catch (error) {
    res.status(500).json({ status: 'error', message: 'Gagal mengambil saldo' });
  }
});

// ==========================================
//   TOPUP SALDO VIA QRIS
// ==========================================

router.post('/topup',
  auth,
  [
    body('amount')
      .isInt({ min: 10000, max: 10000000 })
      .withMessage('Minimal topup Rp10.000, maksimal Rp10.000.000')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          status: 'error',
          errors: errors.array().map(e => ({ field: e.param, message: e.msg }))
        });
      }

      const { amount } = req.body;
      const user = req.user;

      const result = await ronzzpay.createTransaction({
        code: 'qris',
        amount: amount,
        description: `Topup saldo ${user.username} - ${user.email}`
      });

      if (!result.status) {
        return res.status(400).json({
          status: 'error',
          message: result.message || 'Gagal generate QRIS'
        });
      }

      const transaction = new Transaction({
        user: user._id,
        type: 'topup',
        amount: amount,
        fee: result.data.fee || 0,
        method: 'qris',
        status: 'pending',
        referenceId: result.data.reff_id,
        description: `Topup saldo via QRIS`,
        metadata: result.data
      });
      await transaction.save();

      res.json({
        status: 'success',
        data: {
          transactionId: transaction._id,
          reff_id: result.data.reff_id,
          qr_image: result.data.qr_image,
          qr_string: result.data.qr_string,
          amount: amount,
          fee: result.data.fee || 0,
          total: result.data.amount || amount,
          expired_at: result.data.expired_at,
          instructions: result.data.instructions
        }
      });
    } catch (error) {
      console.error('Topup error:', error);
      res.status(500).json({ status: 'error', message: 'Gagal topup saldo' });
    }
  }
);

// ==========================================
//   CEK STATUS TOPUP
// ==========================================

router.get('/topup/status/:reffId', auth, async (req, res) => {
  try {
    const { reffId } = req.params;
    
    const transaction = await Transaction.findOne({ 
      referenceId: reffId,
      user: req.user._id
    });
    
    if (!transaction) {
      return res.status(404).json({
        status: 'error',
        message: 'Transaksi tidak ditemukan'
      });
    }

    const result = await ronzzpay.getTransactionStatus(reffId);
    
    if (result.status && result.data?.status === 'success') {
      await User.findByIdAndUpdate(req.user._id, {
        $inc: { saldo: transaction.amount }
      });
      
      transaction.status = 'success';
      transaction.completedAt = new Date();
      await transaction.save();
    }

    res.json({
      status: 'success',
      data: {
        status: transaction.status,
        amount: transaction.amount,
        createdAt: transaction.createdAt,
        completedAt: transaction.completedAt
      }
    });
  } catch (error) {
    res.status(500).json({ status: 'error', message: 'Gagal cek status' });
  }
});

// ==========================================
//   RIWAYAT TRANSAKSI
// ==========================================

router.get('/history', auth, async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;
    
    const transactions = await Transaction.find({ user: req.user._id })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));
    
    const total = await Transaction.countDocuments({ user: req.user._id });
    
    res.json({
      status: 'success',
      data: {
        transactions,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total,
          totalPages: Math.ceil(total / limit)
        }
      }
    });
  } catch (error) {
    res.status(500).json({ status: 'error', message: 'Gagal mengambil riwayat' });
  }
});

module.exports = router;