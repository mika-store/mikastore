require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Product = require('../models/Product');

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    
    // Buat admin
    const adminExists = await User.findOne({ email: process.env.ADMIN_EMAIL });
    if (!adminExists) {
      const admin = new User({
        username: 'admin',
        email: process.env.ADMIN_EMAIL,
        password: process.env.ADMIN_PASSWORD,
        role: 'superadmin',
        isVerified: true
      });
      await admin.save();
      console.log('✅ Admin created');
    }
    
    // Buat produk contoh
    const adminUser = await User.findOne({ email: process.env.ADMIN_EMAIL });
    
    const products = [
      {
        name: 'Paket Internet 10GB',
        slug: 'paket-internet-10gb',
        description: 'Paket internet 10GB masa aktif 30 hari',
        price: 50000,
        category: 'digital',
        stock: 100,
        seller: adminUser._id
      },
      {
        name: 'Voucher Game 100.000',
        slug: 'voucher-game-100k',
        description: 'Voucher game untuk berbagai platform',
        price: 100000,
        category: 'digital',
        stock: 50,
        seller: adminUser._id
      }
    ];
    
    for (const product of products) {
      const exists = await Product.findOne({ slug: product.slug });
      if (!exists) {
        await new Product(product).save();
        console.log(`✅ Product ${product.name} created`);
      }
    }
    
    console.log('✅ Seeding complete');
    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding error:', error);
    process.exit(1);
  }
};

seed();